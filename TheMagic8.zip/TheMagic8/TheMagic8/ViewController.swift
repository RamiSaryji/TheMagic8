//  TheMagic8
//  Created by Rami Saryji on 15/09/2018.


import UIKit

class ViewController: UIViewController {

    var randomBallNumber = 0
    var ballArray = ["ball1" , "ball2" ,"ball3" ,"ball4" ,"ball5"]
    
    
    @IBOutlet weak var ballimage: UIImageView!
    
    @IBAction func askButtonPressed(_ sender: Any) {
        image ()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        image ()
    }
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        image()
    }

    func image () {
        randomBallNumber = Int(arc4random_uniform((5)))
        ballimage.image = UIImage (named: ballArray[randomBallNumber])
    }

}

